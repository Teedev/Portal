from django.db import models

# Create your models here.
from django.db import models

# class Property(models.Model):
#     property_no = models.CharField(max_length=50)
#     coordinate = models.CharField(max_length=100)
#     location = models.CharField(max_length=100)
#     cost = models.DecimalField(max_digits=15, decimal_places=2)
#     property_type = models.CharField(
#         max_length=20,
#         choices=[("Residential", "Residential"), ("Commercial", "Commercial"), ("Industrial", "Industrial")]
#     )
#     passport = models.ImageField(upload_to='property_passports/', blank=True, null=True)
#
#     def __str__(self):
#         return f"{self.property_no} - {self.property_type}"

class Property(models.Model):
    property_no = models.CharField(max_length=100)
    coordinate = models.CharField(max_length=255)
    location = models.CharField(max_length=255)
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    property_type = models.CharField(max_length=255)
    passport = models.FileField(upload_to='properties/')

    def __str__(self):
        return f"{self.property_no} - {self.location}"



#
# class Contract(models.Model):
#     contract_no = models.CharField(max_length=100)
#     title = models.CharField(max_length=255)
#     company_name = models.CharField(max_length=255)
#     location = models.CharField(max_length=255)
#
#     contract_advert = models.FileField(upload_to='contracts/')
#     company_profile = models.FileField(upload_to='contracts/')
#     contract_agreement = models.FileField(upload_to='contracts/')
#     variations = models.FileField(upload_to='contracts/', blank=True, null=True)
#     applications = models.FileField(upload_to='contracts/')
#     certificate_no_objection = models.FileField(upload_to='contracts/')
#     award_certificate = models.FileField(upload_to='contracts/')
#     completion_certificate = models.FileField(upload_to='contracts/')
#     drawing = models.FileField(upload_to='contracts/')
#     certificate_valuation = models.FileField(upload_to='contracts/')
#     approvals = models.FileField(upload_to='contracts/')
#
#     def __str__(self):
#         return f"{self.contract_no} - {self.title}"




class Contract(models.Model):
    contract_no = models.CharField(max_length=100)
    title = models.CharField(max_length=255)
    company_name = models.CharField(max_length=255)
    location = models.CharField(max_length=255)

    # File Upload Fields
    contract_advert = models.FileField(upload_to='contracts/')
    company_profile = models.FileField(upload_to='contracts/')
    contract_agreement = models.FileField(upload_to='contracts/')
    variations = models.FileField(upload_to='contracts/', blank=True, null=True)
    applications = models.FileField(upload_to='contracts/')
    certificate_no_objection = models.FileField(upload_to='contracts/')
    award_certificate = models.FileField(upload_to='contracts/')
    completion_certificate = models.FileField(upload_to='contracts/')
    drawing = models.FileField(upload_to='contracts/')
    certificate_valuation = models.FileField(upload_to='contracts/')
    approvals = models.FileField(upload_to='contracts/')

    def __str__(self):
        return f"{self.contract_no} - {self.title}"
