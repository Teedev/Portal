from django.urls import path

from . import views
from .views import login_view, listReg, property_form, upload_contract, lands_section_view, success_view, success_view1

urlpatterns = [

  path("login/", login_view, name="login"),
  path("listReg/", listReg, name="listReg"),
  path("property-form/", property_form, name="property_form"),
  path('upload/', upload_contract, name='upload_contract'),
  path('lands_section_view/', lands_section_view, name='lands_section_view'),
  path("success/", success_view, name="success"),
path("success1/", success_view1, name="success1"),
]